# Live (GitHub-Flavored) Markdown Editor

[Use it here](//jbt.github.io/markdown-editor)

Feel free to take the code and copy it and modify it and use it however you like. (If you really want a licence, see [WTFPL](http://www.wtfpl.net/txt/copying/))
